#include <stdio.h>

int ft_sqrt(int nb);

int main(){
	int test;
	scanf("%d", &test);
	printf("you entered %d\n", test);
	test = ft_sqrt(test);
	printf("sqrt is %d\n", test);
}
