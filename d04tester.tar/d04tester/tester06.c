#include <stdio.h>

int ft_is_prime(int nb);

int main(){
	int test;
	scanf("%d", &test);
	printf("you entered %d\n", test);
	test = ft_is_prime(test);
	printf("1 is prime, 0 is not: %d\n", test);
}
