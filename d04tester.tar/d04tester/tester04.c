#include <stdio.h>

int ft_fibonacci(int nb);

int main(){
	int test;
	scanf("%d", &test);
	printf("you entered %d\n", test);
	test = ft_fibonacci(test);
	printf("element is %d\n", test);
}
