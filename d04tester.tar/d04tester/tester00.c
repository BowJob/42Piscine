#include <stdio.h>

int ft_iterative_factorial(int nb);

int main(){
	int test;
	scanf("%d", &test);
	printf("you entered %d\n", test);
	test = ft_iterative_factorial(test);
	printf("factorial is %d\n", test);
}
