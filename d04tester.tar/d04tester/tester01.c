#include <stdio.h>

int ft_recursive_factorial(int nb);

int main(){
	int test;
	scanf("%d", &test);
	printf("you entered %d\n", test);
	test = ft_recursive_factorial(test);
	printf("factorial is %d\n", test);
}
