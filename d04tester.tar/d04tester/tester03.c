#include <stdio.h>

int ft_recursive_power(int nb, int power);

int main(){
	int test;
	int test2;
	int result;
	printf("Enter a number ");
	scanf("%d", &test);
	printf("you entered %d\n", test);
	printf("Enter a power ");
	scanf("%d", &test2);
	printf("you entered %d\n", test2);
	result = ft_recursive_power(test, test2);
	printf("answer is %d\n", result);
}
